# Raksha Bandhan Interactive Website

This is a single-file, mobile-first static website designed for Vercel.

## Deploy to Vercel

1. Upload this folder to a GitHub repository.
2. Import the repository into Vercel.
3. Use the default settings.
4. Deploy.

No build command or backend is required.

## Personalize

Edit `index.html` to replace the sample text and emoji/photo placeholders with your own content.
